
import 'bootstrap';

console.log('init M8PROG');
